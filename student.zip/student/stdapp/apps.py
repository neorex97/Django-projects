from django.apps import AppConfig


class StdappConfig(AppConfig):
    name = 'stdapp'
